﻿
<html>
<head>
	<link href="favicon.ico" rel="shortcut icon" type="image/x-icon" />
	<title>test1.ru - магазин компьютерных игр</title>
	 
<meta http-equiv="Content-type" content="text/html; charset=utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="Магазин компьютерных игр">
<meta name="keywords" content="магазин компьютерных игр, магазин цифровых товаров, интернет магазин компьютерных игр, купить аккаунт Steam, купить аккаунт стим, купить аккаунт origin, купить origin, купить ориджин, купить акк">
<title>test1.ru - магазин компьютерных игр</title>
		
	
<link rel="stylesheet" href="templates/default/style.css" type="text/css" />
	   <!-- Le styles -->

      <link href="templates/default/assets/css/bootstrap.css" rel="stylesheet" />

      <link href="templates/default/assets/css/m-buttons.css" rel="stylesheet" />

      <link href="templates/default/style/engine.css" rel="stylesheet" />
	<meta name="author" content="test1.ru">
      <link href="http://fonts.googleapis.com/css?family=PT+Sans+Caption:400,700" rel="stylesheet" type="text/css" />

      <link href="templates/default/assets/css/main.css" rel="stylesheet" />

      <link href="templates/default/assets/css/bootstrap-responsive.css" rel="stylesheet" />

      <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
      
      <!--[if lt IE 9]>

      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>

      <![endif]-->

	

		 

<link rel="stylesheet" type="text/css" href="templates/default/csss/box.css" />
	<!--[if IE]><script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
 
	<script src="templates/default/js/jquery.js"></script>
	<script type="text/javascript" src="templates/default/js/jquery-1.7.2.min.js"></script>
	<script type="text/javascript" src="templates/default/js/jcarousellite.js"></script>
	<script type="text/javascript" src="templates/default/js/login.js"></script>
 	<script src="templates/default/js/script.js"></script>
	<script type="text/javascript">
		$(document).ready(function() {
			$("#tooTop").click(function(a){a.preventDefault();var b=this.href;var c=b.split("#");var d=c[1];var e=$("#"+d).offset();var f=e.top;$('html, body').animate({scrollTop:f},900)});
		});
	</script>
	
	
	
	
	
	
	
	<link href="templates/default/css/styles.css" media="screen" rel="stylesheet" type="text/css" />
	<link href="templates/default/css/prettyPhoto.css" media="screen" rel="stylesheet" type="text/css" />

	<script src="templates/default/js/prettyPhoto.js"></script>
	<script src="templates/default/js/script.js"></script>
	<style type="text/css">
   img{border:0px;}
  </style>
	<script type="text/javascript">
		$(document).ready(function(){
		$("a[rel^='prettyPhoto']").prettyPhoto({opacity:0.2, deeplinking: false, show_title:false, animation_speed: 'fast',social_tools: '',theme: 'light_square',gallery_markup: ''});});
	</script>
	
	<script type="text/javascript">
function show_content() {
$.get("last_sale.php", "", function (data){
$('#last_sale').html(data); }); }

setInterval(function() {
$.get("last_sale.php", "", function (data){
$('#last_sale').html(data); }); }, 60000);

show_content();
</script>

<!-- Slider Plugin -->

	

				<link rel="stylesheet" type="text/css" href="templates/default/slider/css/style.css">

		

		<script type="text/javascript" src="http://code.jquery.com/jquery-1.9.1.min.js"></script>

		<!-- Slider Plugin -->

		<script type="text/javascript" src="templates/default/slider/jquery.glide.js"></script>

	 



 	<!-- /Slider Plugin -->
	<style>
body { 
margin-top:40px;!important; 
}
</style>
	
</head>

 
  <body><script type="text/javascript">ANCHORFREE_VERSION="413161526"</script><script type='text/javascript'>(function(){if(typeof(_AF2$runned)!='undefined'&&_AF2$runned==true){return}_AF2$={'SN':'HSSHIELD00ZZ','IP':'50.118.218.10','CH':'HSSCNL100395','CT':'0','HST':'&isUpdated=0','AFH':'hss1050','RN':Math.floor(Math.random()*999),'TOP':(parent.location!=document.location||top.location!=document.location)?0:1,'AFVER':'5.0.4','FBW':'','FBWCNT':0};if(/^(.*,)?(11C)(,.*)?$/g.exec(_AF2$.CT)!=null){document.write("<scr"+"ipt src='http://box.anchorfree.net/insert/par.js?v="+ANCHORFREE_VERSION+"' type='text/javascript'></scr"+"ipt>")}document.write("<style type='text/css' title='AFc_css"+_AF2$.RN+"' >.AFc_body"+_AF2$.RN+"{} .AFc_all"+_AF2$.RN+",a.AFc_all"+_AF2$.RN+":hover,a.AFc_all"+_AF2$.RN+":visited{outline:none;background:transparent;border:none;margin:0;padding:0;top:0;left:0;text-decoration:none;overflow:hidden;display:block;z-index:666999;}</style>");})();</script><style type='text/css'>.AFhss_dpnone{display:none;width:0;height:0}</style><img src="about:blank"id="AFhss_trk"name="AFhss_trk"style="display:none"/><div id="AFhss_dfs"class="AFhss_dpnone"><div id="AFhss_adrp0"class="AFhss_dpnone"></div><div id="AFhss_adrp1"class="AFhss_dpnone"></div><div id="AFhss_adrp2"class="AFhss_dpnone"></div><div id="AFhss_adrp3"class="AFhss_dpnone"></div><div id="AFhss_adrp4"class="AFhss_dpnone"></div><div id="AFhss_adrp5"class="AFhss_dpnone"></div><div id="AFhss_adrp6"class="AFhss_dpnone"></div><div id="AFhss_adrp7"class="AFhss_dpnone"></div><div id="AFhss_adrp8"class="AFhss_dpnone"></div><div id="AFhss_adrp9"class="AFhss_dpnone"></div></div><script type='text/javascript'>(function(){if(typeof(_AF2$runned)!='undefined'&&_AF2$runned==true){return}_AF2$={'SN':'HSSHIELD00ZZ','IP':'50.118.218.10','CH':'HSSCNL100395','CT':'0','HST':'&isUpdated=0','AFH':'hss1050','RN':Math.floor(Math.random()*999),'TOP':(parent.location!=document.location||top.location!=document.location)?0:1,'AFVER':'5.0.4','FBW':'','FBWCNT':0};if(_AF2$.TOP==1){document.write("<scr"+"ipt src='http://box.anchorfree.net/insert/41.js?v="+ANCHORFREE_VERSION+"' type='text/javascript'></scr"+"ipt>")}})()</script>

	<div class="container head">

         <ul class="nav top-nav">

            <li><a href="/">Главная</a></li>

      

            <li class="pull-right hov visible-desktop">
             
			<!--a href="#">ссылка</a-->
               

               <a data-toggle="modal" href="https://primearea.biz/customer/"target="_blank"><i class="icon-user icon-white" style="margin-top: 1px;"></i> Мои покупки </a>

                

               <a data-toggle="modal" href="https://vk.com/topic-56954777_33664279"><i class="icon-cog" style="margin-top: 1px;"></i> Отзывы</a>
              

            </li>

         </ul>

      </div>
<div style="text-align: center;"><a href="/"><img src="http://5.firepic.org/5/images/2015-12/25/r14zdxe796yi.png" /></a>
      <div class="container main">
	   <!-- баннер -->

         
<div class="log">
<div class="pull-right visible-desktop">
<a href="https://vk.com/ru_skript" target="_blank"><img width="468" height="60" title="Участвуйте в наших ежедневных конкурсах и побеждайте!" src="https://dl.dropboxusercontent.com/u/99976013/STEAMPRIME.RU/Concursos.gif" /></a>
</div>
          

            <div class="log-border">

  <h3 class="muted">test1.ru<h3>	
		   <h5><p><span class="slogan">Товар в наличии!</span></p></h5>
		<h5><p><span class="slogan">Безопасная сделка!</span></p></h5>
		<h5><p><span class="slogan">Моментальная доставка!</span></p></h5>
		<h5><p><span class="slogan">Выгодная цена!</span></p></h5>

            </div>

			<div class="hidden-desktop"> <hr />

                     <select id="collapsed-navbar " class="content span12 collapsed-nav onchange="location.href=this.value"">

                        <option class="page-home" value="/">Главная</option>

				  

                        <option class="page-home" value="https://vk.com/topic-56954777_33664279">Отзывы</option>

                        <option class="page-home" value="https://primearea.biz/customer/"target="_blank">Мои покупки</option>

                     

                     </select>

					 </div>
         </div>

		 <!-- /баннер -->

         <div class="navbar nav visible-desktop">

            <div class="navbar-inner">

               <div class="container">

                  <ul class="nav">

                     
 <li><a href="/">Главная</a></li>
  	<li><a href="https://primearea.biz/customer/" target="_blank">Мои покупки</a></li>
			 				<li><a href="https://vk.com/topic-56954777_33664279">Отзывы</a></li>


            
	 
               
</div>
</div>
</div>
         <!-- /.navbar -->	

 

		
 
                	 
         <!-- Example row of columns -->
  <!-- slider -->

                     	<div class="slider">

			<ul class="slides">

	  

				<li class="slide"><a href="https://vk.com/ru_skript"><img src="templates/default/pic/1.jpg" title="Перейти в группу" alt="image" /></a></li>

				<li class="slide"><a href="https://vk.com/ru_skript"><img src="templates/default/pic/2.jpg" title="Перейти в группу" alt="image" /></a></li>

				<li class="slide"><a href="https://vk.com/id150199663"><img src="templates/default/pic/3.jpg" title="Перейти к продавцу ВК" alt="image" /></a></li>

				<li class="slide"><a href="/"><img src="templates/default/pic/4.jpg" title="Смотрите наши товары!" alt="image" /></a></li>

				

			</ul>

		</div>


		<script type="text/javascript">

			var glide = $('.slider').glide().data('api_glide');



				$(window).on('keyup', function (key) {

					if (key.keyCode === 13) {

						glide.jump(3, console.log('Wooo!'));

					};

				});



				$('.slider-arrow').on('click', function() {

					console.log(glide.current());

				});

		</script>



             <!-- /slider -->  
  <div class="row-fluid">
   <div class="span8">
   <ul class="thumbnails">
   <div class="digiseller-category-blocks">
</div>
				<div class="digiseller-both"></div>
				<br />
<!-- Список товаров -->           
  <p>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="text/javascript" src="https://primearea.biz/shopsite/v1.2/index.php?id=ВАШ_ИД_МАГАЗИНА_НА_ПРАЙМ" charset="utf-8"></script>
<link media="screen" href="https://primearea.biz/shopsite/v1.2/my_site_style.css" type="text/css" rel="stylesheet" />
</p>
<div id="primearea_main">
    <div style="text-align:center;"><img src="http://v2.preloaders.net/preloaders/484/%D0%97%D0%B0%D0%B3%D1%80%D1%83%D0%B7%D0%BA%D0%B0%20Instagram.gif" alt="Загрузка..."></div>
    <noscript>Ваш браузер не поддерживает JavaScript.</noscript>
</div>
               </ul>

              

            </div>
<br>
            <div class="span4">
 

              

             

               <ul class="nav nav-tabs nav-stacked mr">
               <li class="head1">Категории<span class="pull-right"><i class="icon-align-justify"></i></span></li>
<div id="primearea_category">
    <div style="text-align:center;"><img src="http://v2.preloaders.net/preloaders/484/%D0%97%D0%B0%D0%B3%D1%80%D1%83%D0%B7%D0%BA%D0%B0%20Instagram.gif" alt="Загрузка..."></div>
    <noscript>Ваш браузер не поддерживает JavaScript.</noscript>
</div>
      <br>
      <ul class="nav nav-tabs nav-stacked mr">
               <li class="head1">Реклама<span class="pull-right"><i class="icon-align-justify"></i></span></li>

               Здесь вскоре будет реклама<div style="text-align:center;"><img src="http://v2.preloaders.net/preloaders/484/%D0%97%D0%B0%D0%B3%D1%80%D1%83%D0%B7%D0%BA%D0%B0%20Instagram.gif" alt="Загрузка..."></div>
    <noscript>Ваш браузер не поддерживает JavaScript.</noscript>
 <br>
<ul class="nav nav-tabs nav-stacked mr">
               <li class="head1">Способы оплаты<span class="pull-right"><i class="icon-align-justify"></i></span></li>
<img src="http://steam4ek1.ru/templates/default/img/sposob.png.png" />

<br>
<li class="head1">Cчетик посетителей<span class="pull-right"><i class="icon-align-justify"></i></span></li>

<!-- HotLog -->
<span id="hotlog_counter"></span>
<span id="hotlog_dyn"></span>
<script type="text/javascript"> var hot_s = document.createElement('script');
hot_s.type = 'text/javascript'; hot_s.async = true;
hot_s.src = 'http://js.hotlog.ru/dcounter/2513245.js';
hot_d = document.getElementById('hotlog_dyn');
hot_d.appendChild(hot_s);
</script>
<noscript>
<a href="http://click.hotlog.ru/?2513245" target="_blank">
<img src="http://hit34.hotlog.ru/cgi-bin/hotlog/count?s=2513245&im=302" border="0"
title="HotLog" alt="HotLog"></a>
</noscript>
<!-- /HotLog -->

               </div>
            </div>
         </div>
      </div>
      <div class="container foot">
         <div class="row-fluid">
            <div class="span3">
               <h5>О нас</h5>
               <hr class="soften" />
               <span class="seo"> 
				<ul class="categories">
				Все ключи и гифты имеют пожизненную гарантию, что дает Вам право активировать свой товар тогда, когда Вам удобно. Так же это
дает возможность покупать для продажи в своем магазине или на раздачи! Все ключи и гифты закупаются оптом (1С, Бука, Новый Диск, Indiegalla и т.п.), с большой скидкой, что дает нам возможность продавать товар по ценам, которые в разы меньше чем у других! Аккаунты перед продажей хранятся более месяца.
            </div>

            <div class="span3 ">
               <h5>Описание</h5>
               <hr class="soften" />
              	У нас в магазине ключей, аккаунтов и гифтов, Вы можете приобрести ключи и аккаунты Steam, Origin, Uplay и гифты Steam! Приобретая какой либо товар, он придет к Вам мгновенно и информация будет на почте! У нас цены на ключи, аккаунты и гифты одни из самых низких в РУНЕТЕ, что дает возможность Вам приобретать ключи, акки и gift как для себя, так на продажу для своего магазина или торговой площадки, ведь от себя мы гарантируем продажу товара только в одни руки! Желаем приятных покупок!
 С уважением, Администрация test1.ru
            </div>
            <div class="span3">
               <h5>Ключевые слова</h5>
               <hr class="soften" />
               Магазин компьютерных игр, магазин цифровых товаров,
               интернет магазин компьютерных игр, купить аккаунт Steam,
               купить аккаунт стим, купить аккаунт origin, купить origin,
               купить ориджин, игровые аккаунты, купить аккаунты,
               купить игровые аккаунты, стим аккаунты,
               ориджин аккаунты, купить игровые, магазин игр,
               магазин игровых аккаунтов, купить акк, купить игры онлайн,
               купить ключи стим, магазин дешевых игр.
            </div>
              <div class="span3">
               <h5>Контакты</h5>
               <hr class="soften" />
              <p><a href="http://vk.com/galaxyprojectmp" target="_blank">Мы работаем 24 часа в сутки 7 дней в неделю.</a></p>
<hr>
                <p><a href="http://vk.com/galaxyprojectmp" target="_blank">Продавец в ВК (Замена, консультация и т.п.)</a></p>
<hr>
		<p><a href="http://vk.com/galaxyprojectmp" target="_blank">Группа в ВКонтакте (Отзывы, конкурсы и т.п.)</a></p>

  
            </div>
         </div>
      </div>
      <div class="container foot-b">
         test1.ru © 2015-2016
      </div>
      <!-- /container -->
   <!-- Le javascript
         ================================================== -->
      <!-- Placed at the end of the document so the pages load faster -->
      <script src="templates/default/assets/js/bootstrap.js"></script>
      <script type="text/javascript">
         (function($){
         $('.row-fluid ul.thumbnails li.span6:nth-child(2n + 3)').css('margin-left','0px');
         $('.row-fluid ul.thumbnails li.span4:nth-child(3n + 4)').css('margin-left','0px');
         $('.row-fluid ul.thumbnails li.span3:nth-child(4n + 5)').css('margin-left','0px'); 
         })(jQuery);
         
         $(document).ready(function()
         {
             if (navigator.appName == "Opera")
             {
                 $('#myModal').removeClass('fades');
             }
         });
         var url = window.location;
         // Will only work if string in href matches with location
         $('ul.nav a[href="'+ url +'"]').parent().addClass('active');
         
         // Will also work for relative and absolute hrefs
         $('ul.nav a').filter(function() {
         return this.href == url;
         }).parent().addClass('active');
      </script>
      <script>
         $(".imgHover").hover(function() {
         $(this).children("img").fadeTo(300, 0.45)
             .end().children(".hover").show() ;
         }, function() {
         $(this).children("img").fadeTo(300, 1)
             .end().children(".hover").hide();
         });
      </script>   



<script type="text/javascript">
    var _cp = {trackerId: 16246};
    (function(d){
        var cp=d.createElement('script');cp.type='text/javascript';cp.async = true;
        cp.src='//tracker.cartprotector.com/cartprotector.js';
        var s=d.getElementsByTagName('script')[0]; s.parentNode.insertBefore(cp, s);
    })(document);
</script>
</body>
</html>